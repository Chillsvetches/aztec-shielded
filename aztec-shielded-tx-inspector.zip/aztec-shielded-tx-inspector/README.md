Aztec Shielded Tx Inspector
=============================

Short description
-----------------
CLI tool template for parsing and tagging shielded Aztec transactions from a local JSON export.

What this project does
----------------------
- Loads a local JSON file that contains Aztec-style transactions.
- Filters transactions by address, token symbol, and minimum value.
- Prints a compact report to the console.

Files
-----
- app.py  - main script with CLI interface.
- README.md - project description and usage notes.

How to use
----------
1. Put your exported Aztec transaction JSON into a file, for example: `aztec-txs.json`.
2. Run:

   python app.py --file aztec-txs.json --address 0xYourAddress --token USDC --min-value 10

3. The script will print all matching transactions.

Notes
-----
This is a minimal template and does **not** connect directly to the network or any 3rd-party API.
Extend it with real Aztec indexer or RPC logic if needed.
