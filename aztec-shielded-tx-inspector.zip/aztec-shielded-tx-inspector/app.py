"""
Aztec Shielded Tx Inspector
CLI tool template for parsing and tagging shielded Aztec transactions from a local JSON export.
"""

import argparse
import json
import csv
from dataclasses import dataclass
from typing import List, Dict, Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Aztec Shielded Tx Inspector")
    parser.add_argument(
        "--file",
        "-f",
        required=False,
        help="Path to the local data file (JSON or CSV, depending on the project).",
    )
    parser.add_argument(
        "--days",
        type=int,
        default=30,
        help="Optional days window or generic integer parameter (project specific).",
    )
    parser.add_argument(
        "--address",
        help="Optional wallet address filter (project specific).",
    )
    parser.add_argument(
        "--token",
        help="Optional token symbol filter (project specific).",
    )
    parser.add_argument(
        "--min-value",
        type=float,
        default=0.0,
        help="Optional minimum value filter (project specific).",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=20,
        help="Optional limit for top results (project specific).",
    )
    return parser.parse_args()


def load_data(path: str) -> List[Dict[str, Any]]:
    if not path:
        print("No --file provided. Using built-in demo data.")
        return [
            dict(wallet="0xDEMO", token="USDC", value=42, action="demo", timestamp="2024-01-01T00:00:00Z")
        ]

    if path.lower().endswith(".json"):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    elif path.lower().endswith(".csv"):
        with open(path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            return list(reader)
    else:
        raise ValueError("Unsupported file format. Use JSON or CSV.")


def analyze(data: List[Dict[str, Any]]) -> Dict[str, Any]:
    # This is intentionally generic. Adjust the logic to your project.
    total = 0.0
    count = 0
    per_wallet: Dict[str, float] = dict()
    for row in data:
        value = float(row.get("value", 0))
        wallet = row.get("wallet", "UNKNOWN")
        total += value
        count += 1
        per_wallet[wallet] = per_wallet.get(wallet, 0.0) + value

    return dict(
        total_value=total,
        tx_count=count,
        per_wallet=per_wallet,
    )


def main() -> None:
    args = parse_args()
    data = load_data(args.file)
    result = analyze(data)

    print("=== Aztec Shielded Tx Inspector ===")
    print("Records processed:", result["tx_count"])
    print("Total value:", result["total_value"])
    print("Per wallet:")
    items = sorted(result["per_wallet"].items(), key=lambda x: x[1], reverse=True)[: args.top]
    for wallet, value in items:
        print("  ", wallet, "->", value)


if __name__ == "__main__":
    main()
